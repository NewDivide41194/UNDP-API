
const reportController=require("./controller.report")
module.exports = {
  reportController
};