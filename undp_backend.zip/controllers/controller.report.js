const { reportService } = require("../services");
const response = require("../response/response");
const saltRounds = 10;

const GetReport=(req,res,next)=>{
res.json(response({success: false, message: "Report" }))
}

module.exports = { GetReport };
