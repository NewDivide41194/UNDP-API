const surveydb = require('./myQueries')

module.exports =  {surveydb}