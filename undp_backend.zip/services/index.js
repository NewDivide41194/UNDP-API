const reportService=require("./service.report")

module.exports = {
reportService
};
