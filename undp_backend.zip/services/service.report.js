const { surveydb } = require("../database");

const getReport = (countryId) => {
  return surveydb.getReport(countryId);
};

module.exports = { getReport };
